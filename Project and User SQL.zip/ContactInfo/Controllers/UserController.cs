﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using ContactInfo.Models;

namespace ContactInfo.Controllers
{
    public class UserController : Controller
    {
        UserEntities db = new UserEntities();
        // GET: User
        public ActionResult Index()
        {
            return View(db.Users.ToList());
        }

        // GET: User/Details/5
        public ActionResult Details(int id)
        {
            var userData = db.Users.Where(a => a.UserId == id).FirstOrDefault();
            return View(userData);
        }

        // GET: User/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: User/Create
        [HttpPost]
        public ActionResult Create(FormCollection formCollection)
        {
            try
            {
                // TODO: Add insert logic here
                User user = new User
                {
                    FirstName = formCollection["FirstName"],
                    LastName = formCollection["LastName"],
                    Email = formCollection["Email"],
                    PhoneNumber = formCollection["PhoneNumber"],
                    Status = formCollection["Status"] == "false" ? false : true
                };

                db.Users.Add(user);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch (Exception e)
            {
                var a = e.Message;
                return View();
            }
        }

        // GET: User/Edit/5
        public ActionResult Edit(int id)
        {
            var userData = db.Users.Where(a => a.UserId == id).FirstOrDefault();
            return View(userData);
        }

        // POST: User/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection formCollection)
        {
            try
            {
                // TODO: Add update logic here
                var userData = db.Users.Where(a => a.UserId == id).FirstOrDefault();
                bool updated = TryUpdateModel(userData, formCollection);
                if(updated && ModelState.IsValid)
                {
                    db.SaveChanges();
                }
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: User/Delete/5
        public ActionResult Delete(int id)
        {
            var userData = db.Users.Where(a => a.UserId == id).FirstOrDefault();
            return View(userData);
        }

        // POST: User/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here
                User user = db.Users.Find(id);
                db.Entry(user).State = EntityState.Deleted;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
