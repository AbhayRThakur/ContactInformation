SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[User](

       [UserId] [int] IDENTITY(1,1) NOT NULL,
       [FirstName] [nvarchar](50) NULL,
       [LastName] [nvarchar](50) NULL,
       [Email] [nvarchar](300) NULL,
       [PhoneNumber] [nvarchar](20) NOT NULL,
       [Status] [bit] NOT NULL,

CONSTRAINT [PK_User] PRIMARY KEY CLUSTERED

(
       [UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

) ON [PRIMARY]

--ALTER TABLE [dbo].[User] ADD  CONSTRAINT [DF_User_PhoneNumber]  DEFAULT ((0)) FOR [PhoneNumber]
ALTER TABLE [dbo].[User] ADD  CONSTRAINT [DF_User_Status]  DEFAULT ((0)) FOR [Status]

GO